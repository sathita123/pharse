from Getstudyinfo import  get_study_info_for_teacher

from Zip_readhtml import upload_zip_html

from flask import Flask, jsonify, request, session
from flask_cors import CORS
import pymysql
import jwt
import hashlib
from jwt_ import token_required

import os

from werkzeug.utils import secure_filename


def connect_db(dbname):
    mydb = pymysql.connect(
        host="10.36.16.177",
        user="root",
        port=3306,
        password="0948544473Za@",
        database="graduation_requirments_system"
    )
    return mydb
 

SECRET_KEY = "C@tW@naBE@CaT_=!__EieiLnwza00&7"
RANDOM_PASS_LENGTH = 6
# html_read=readhtml.ReadHtml('./1282.html')
# study = html_read.ReadHtml()








# ----------------------------------------------------------------------------------------------------------
app = Flask(__name__)
UPLOAD_FOLDER = './'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
CORS(app, supports_credentials=True)
# app.secret_key = "caircocoders-ednalan"
app.config['SECRET_KEY'] = SECRET_KEY

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

ALLOWED_EXTENSIONS = set(['html'])



@app.route('/')
def main():
    return 'Home'




# ================================= ขึ้นรายชื่อนิสิตที่ต้องการให้อาจารย์ตรวจสอบ ====================================  7/10/65


@app.route("/get-student-data-to-check", methods=['POST'])
@token_required
def get_student_data_require(current_user):
    try:
        json_data  = request.json
        status = json_data['status']
        year = json_data['year']
        admin_id = current_user["current_user"][0]
        section = json_data['section']
        db = connect_db('graduation_requirments_system')
        cur = db.cursor()
        if year == 'all':
            sql = "SELECT * FROM student_info WHERE student_info.deleted = 0 and admin_id = %s"
            cur.execute(sql,(admin_id))
        else:
            sql = "SELECT * FROM student_info WHERE student_info.deleted = 0 and student_info.year = %s and admin_id = %s"
            cur.execute(sql, (year,admin_id))
        std = cur.fetchall()
        std_info = {'data': []}
        for i in std:
            sql = "SELECT * FROM cond_progress WHERE std_id = %s and deleted = 0 and status = 'NOT PASS' and admin_id = %s"
            val = (i[0],admin_id)
            cur.execute(sql,val)
            study_status = cur.fetchone()

            sql = "SELECT * FROM progress_info WHERE std_id = %s and deleted = 0 and status = 'UNCOMMON' and admin_id = %s"
            val = (i[0],admin_id)
            cur.execute(sql,val)
            uncom_status = cur.fetchone()
            print(uncom_status)
           
            if study_status is not None:
                std_status = "NOT PASS"
            else:
                std_status = "PASS"

            if uncom_status is not None:
                std_status = "UNCOMMON"

            std_info['data'].append({
                'std_id': i[0],
                'name': i[1],
                'surname': i[2],
                'data_date': i[12],
                'data_time': i[14],
                'section': i[19],
                'std_year':i[17],
                'status': std_status
            })
        std_dict = {'data': std_info}
        print(std_dict)
        if status ==0 :
            std_dict['data']['data'] = [i for i in std_dict['data']['data'] if i['status'] == 'NOT PASS']
        elif status == 1:
            std_dict['data']['data'] = [i for i in std_dict['data']['data'] if i['status'] == 'PASS']
        elif status == 2:
            pass
        elif status == 3:
            std_dict['data']['data'] = [i for i in std_dict['data']['data'] if i['status'] == 'UNCOMMON']
        if section == 'all':
            pass
        else:
            std_dict['data']['data'] = [i for i in std_dict['data']['data'] if f"{i['section']}" == section]
        return jsonify(std_dict)
    except Exception as e:
        return {
            'message': 'fail',
            'error': str(e)
        }
# ========================================= ตรวจสอบการเรียนของนิสิตในที่ปรึกษา =============================================#/////7/10/65

# /////////////////////////////////////////////////////////////////////////// 7/10/65 ปุ่ม ตรวสอบจบ


@app.route("/get-sub-progress-info-for-teacher", methods=['PATCH'])
@token_required
def get_sub_progress_info_for_teacher(current_user):
    try:
        data = request.json
        admin_id = current_user["current_user"][0]
        data = request.json
        std_id = data['std_id']
        db = connect_db('graduation_requirments_system')
        cur = db.cursor()
        cur.execute(
            "SELECT * FROM student_info WHERE std_id =%s AND deleted = 0 and admin_id = %s", (std_id,admin_id))
        current = cur.fetchone()
        data_date = current[12]
        data_time = current[14]
        sub_prog = get_study_info_for_teacher(std_id, data_date, data_time,admin_id)
        data_use = sub_prog['data_use']
        sub_code = sub_prog['sub_code']
        return {
            "data": data_use,
            "sub_code": sub_code,
            "data_date": data_date,
            "data_time": data_time,
            "std_id": std_id,
            "std_name":current[1],
            "std_surname":current[2],
        }
    except Exception as e:
        return {
            'error': str(e),
            'message': 'fail'
        }


@app.route("/upload-zip", methods=['POST'])
@token_required
def upload_zip(current_user):
    admin_id = current_user["current_user"][0]

    target = os.path.join(UPLOAD_FOLDER, 'test_file')
    if not os.path.isdir(target):
        os.mkdir(target)
    file = request.files["file"]
    year = request.form['year']
    section =  request.form['section']
    filename =secure_filename(file.filename)
    path = './unzipfile'
    if filename.split('.')[-1] == 'rar' or filename.split('.')[-1] == 'zip':
        # try:
        destination = "/".join([target, filename])
        file.save(destination)
        session['uploadFilePath'] = destination
        file_path = f"./test_file/{filename}"
        file_name = filename
        try:
            response = upload_zip_html(file_path, file_name, path,year,admin_id,section)
        except Exception as e:
            # delete file
            print(e)
            try:
                print(file_name)
                os.remove(f"./test_file/{filename}")
                del_path=f"./unzipfile/{filename.split('.')[0]}"
                
                for htmlfile in os.listdir(del_path):
                    delfile = del_path +"/"+ htmlfile
                    os.remove(delfile)
                os.rmdir(f"./unzipfile/{filename.split('.')[0]}")
                return {
                "message": "upload fail",
                }
            except Exception as e:
                return {
                    "message": "clear file fail",
                    "error": str(e)
                }
        print(response)
        if response['message'] == 'success':
            try:
                print(file_name)
                os.remove(f"./test_file/{filename}")
                del_path=f"./unzipfile/{filename.split('.')[0]}"
                
                for htmlfile in os.listdir(del_path):
                    delfile = del_path +"/"+ htmlfile
                    os.remove(delfile)
                os.rmdir(f"./unzipfile/{filename.split('.')[0]}")
            except Exception as e:
                return {
                    "message": "clear file fail",
                    "error": str(e)
                }
            return {
                "message": "success",
            }
        else:
            return response
        
    else:
        return {
            "message": ".rar or .zip only",
        }
    

@app.route("/clear-all", methods=['POST'])
@token_required
def clear_all(current_user):
    admin_id = current_user["current_user"][0]
    try:
            mydb = connect_db('graduation_requirments_system')
            c = mydb.cursor()
            c.execute(
                    "UPDATE student_info SET deleted = 1 where admin_id = %s", (admin_id))
            mydb.commit()
            c.execute(
                    "UPDATE study_info SET deleted = 1 where admin_id = %s", (admin_id))
            mydb.commit()
            c.execute(
                    "UPDATE progress_info SET deleted = 1 where admin_id = %s", (admin_id))
            mydb.commit()
            c.execute(
                    "UPDATE cond_progress SET deleted = 1 where admin_id = %s", (admin_id))
            mydb.commit()
            c.execute(
                    "UPDATE sub_in_cond_info SET deleted = 1 where admin_id = %s", (admin_id))
            mydb.commit()
            
            resp = {
                'message': 'success',
            }
    except Exception as e:
            resp={
                    'message': 'error clear data',
            }
    return resp

@app.route("/log-in", methods=['POST'])
def login():
    try:
        # email='xxx.y@ku.th'
        # password='xxx03665'
        data = request.json
        print(data)
        password = data['password']
        password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()
        mydb = connect_db('graduation_requirments_system')
        c = mydb.cursor()
        c.execute("SELECT * FROM admin_info where email = %s AND password = %s  AND deleted = 0",
                  (data['email'], password_hash))
        data_admin = c.fetchone()
        print(data_admin)

        if data_admin is None:
            return {
            "message": "Something went wrong!",
            "error": str(e),
            "data": None
        }, 500
            
        else:
            try:
                payload = {
                    "email": data_admin[1],
                    "name": data_admin[3],
                    "surname": data_admin[4],
                    "role": "admin"
                }
                payload["token"] = jwt.encode(
                    {"email": data_admin[1], "role": "admin"}, app.config['SECRET_KEY'], algorithm='HS256')
                return {
                    "message": "Login Successful",
                    "data": payload,
                }, 200
            except Exception as e:
                return {
                    "message": "Something went wrong",
                    "data": None,
                    "error": str(e)
                }, 500
    except Exception as e:
        return {
            "message": "Something went wrong!",
            "error": str(e),
            "data": None
        }, 500




def create_app(app):
    return app

if __name__ == '__main__':
    create_app = create_app(app)
    create_app.run("0.0.0.0",5000,debug=True)
else:
    create_app = create_app(app)
    # app.run(host="10.36.17.127",port=5000,debug=True)
