from bs4 import BeautifulSoup

class ReadHtml():
    def __init__(self,file):
        self.file = file
        self.soup = BeautifulSoup(open(self.file, mode='r',encoding ="cp874"),'html.parser')
        self.test =self.soup.find_all('td',class_=['tr','head_sm'])
        self.id =self.soup.find_all("span",class_="detail")
        self.group=[]
        self.group2=[]
        self.std_id=""
        self.count=0
    def ReadHtml(self):
        self.std_id = self.id[0].text
        self.name = self.id[4].text.split()[1]
        self.surname = self.id[4].text.split()[2]
        for i in self.test:
            if 'Semester' in i.text:
                k=i.text
                j=k.split()
                if 'First' in j:
                    sem='1'
                    y=j[2]
                elif 'Second' in j:
                    sem='2'
                    y=j[2]
            elif 'Summer' in i.text:
                tmp=int(j[2])+1
                sem='1'
                y=tmp
            else:
                self.count+=1
                self.group.append(i.text)
                if self.count ==4:
                    self.group.append(sem)
                    self.group.append(y)
                    self.group2.append(self.group)
                    self.group=[]
                    self.count=0
        for i in self.group2:
            print(i)
        # print(self.name)
        # print(self.surname)
        return(self.group2,self.std_id,self.name,self.surname)

# if __name__ == "__main__":
#     test = ReadHtml('./1282.html')
#     study = test.ReadHtml()
    # print(test.ReadHtml())