
from functools import wraps
import jwt
from flask import request
from flask import current_app
from functools import wraps

import pymysql


class INIT:
    host = 'localhost'
    user = 'root'
    passwd = 'Laksamee@3@'
    db = 'graduation_requirments_system'
    charset = 'utf8'


def connect_sql():
    mydb = pymysql.connect(
        host="10.36.16.177",
        user="root",
        port=3306,
        password="0948544473Za@",
        database="graduation_requirments_system"
    )
    return mydb


def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        conn = connect_sql()
        cursor = conn.cursor()
        token = None
        if "Authorization" in request.headers:
            token = request.headers["Authorization"].split(" ")[1]
        if token == None:
            # print(55555555555555555555555555)
            return {
                "message": "Authentication Token is missing!",
                "data": None,
                "error": "Unauthorized",
                'status': 'Not OK'
            }, 401
        try:
            # print('ew')
            data = jwt.decode(
                token, current_app.config["SECRET_KEY"], algorithms=["HS256"])
            # print(data)

            # get current_user from database using data["email"] use pymyql
            if data["role"] == "admin":
                cursor.execute(
                    "select * from admin_info where email = %s", (data["email"]))
                current_user = cursor.fetchone()
                current_user_dict = {"current_user": current_user,
                                     "role": "admin", 'status': 'OK'}

                if len(current_user) == 0:
                    return {
                        "message": "Invalid Authentication token!",
                        "data": None,
                        "error": "Unauthorized",
                        'status': 'Not OK'
                    }, 401
            
        except Exception as e:
            return {
                "message": "Invalid Authentication token!",
                "data": None,
                'status': 'Not OK'
            }, 500

        return f(current_user_dict, *args, **kwargs)

    return decorated
