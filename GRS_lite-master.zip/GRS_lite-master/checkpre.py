import pymysql


def connect_db(dbname):
    mydb = pymysql.connect(
        host="10.36.16.177",
        user="root",
        port=3306,
        password="0948544473Za@",
        database="graduation_requirments_system"
    
    )
    return mydb



def find_prerequisite(pre, subject, group):
    for j in pre:
        if j['sub_code'] == subject:
            group.append([j['sub_code'], j["prerequisite"]])
            for m, k in enumerate(j['prerequisite']):
                find_prerequisite(pre, k, group)
    return (group)


def find_edit(edit_):
    n = []
    for i in edit_:
        m = []
        for j in range(int(i), int(i)+5):
            m.append(j)
        n.append(m)
    return (n)


def edit_use(num, n_edit, edit_):
    for i, v in enumerate(n_edit):
        if int(num) in v:
            return (edit_[i])


def group_pre_sub(group1):
    test = []
    for i in group1:
        g = []
        for j in group1:
            if i[0] == j[0]:
                if j[1] not in g:
                    g.append(j[1])
        if [i[0], g] not in test:
            test.append([i[0], g])
    return (test)


def compare(new_test, graded_sub):
    Ispass = []
    count = 0
    count_main = 0
    for inx,i in enumerate(new_test):
        Ispass.append([])
        # print(i)
        for e in i[1]:
            Ispass[count_main].append([])

            for r in e:
                if r == 'None':
                    Ispass[count_main][count] += 1,
                elif r in graded_sub:
                    Ispass[count_main][count] += 1,
                else:
                    Ispass[count_main][count] += 0,

            count += 1
        count_main += 1
        count = 0
        # print(Ispass)    
    count = 0
    l = []
    for inx,i in enumerate(Ispass):
        l.append([])
        for e in i:

            l[count].append(not (0 in e))
            # print(l[count])
        count += 1
    # print(l)

    result = list(map(lambda x: True in x, l))

    if False in result:
        return ('NOT PASS')
    else:
        return ('PASS')


class checkPRE():
    def __init__(self, std, current_day, current_time,admin_id):
        self.std = std  # '6221601169'
        self.current_day = current_day
        self.current_time = current_time
        self.admin_id = admin_id
    def check_pre(self):
        db = connect_db('graduation_requirments_system')
        cur = db.cursor()
        cur.execute("SELECT * FROM subject_info")
        subject = cur.fetchall()

        cur.execute("SELECT * FROM study_info WHERE deleted = 0 AND date = %s AND time = %s AND admin_id = %s",
                    (self.current_day, self.current_time, self.admin_id))
        std = cur.fetchall()

        cur.execute("SELECT * FROM condition_info")
        cond = cur.fetchall()

        cur.execute("SELECT * FROM prerequisite_info")
        pre = cur.fetchall()

        cur.execute("SELECT * FROM student_info WHERE std_id = %s and admin_id = %s", (self.std, self.admin_id))
        std_info = cur.fetchone()


        course = std_info[3].split('-')[1]



        pre_dict = {"data": []}
        for i in pre:
            pre_dict["data"].append(
                {
                    'pregroup_id': i[0],
                    'sub_code': i[1],
                    'prerequisite': [i[2], i[3], i[4]],
                }
            )
        cond_dict = {"data": []}
        for i in cond:
            cond_dict["data"].append(
                {
                    'con_id': i[0],
                    'section': i[1],
                    'group': i[2],
                    'subject_group': i[3],
                    'affiliation': i[4],
                    'credits': i[5],
                    'course': i[6],
                }
            )

        edit_ = []
        for i, v in enumerate(subject):
            if v[2] != 'หมวดวิชาศึกษาทั่วไป':
                if v[9] not in edit_:
                    edit_.append(v[9])


        edit_gen = []
        for i, v in enumerate(subject):
            if v[2] == 'หมวดวิชาศึกษาทั่วไป':
                if v[9] != 'None' and v[9] not in edit_gen:
                    edit_gen.append(v[9])


        n_edit_ = find_edit(edit_)

        n_edit_gen = find_edit(edit_gen)


        student = str(self.std)

        a = '25'+str(student[0])+str(student[1])


        std_dict = {"data": []}
        for i in std:
            if i[1] == student:
                std_dict["data"].append(
                    {
                        'study_id': i[0],
                        'std_id': i[1],
                        'sub_id': i[2],
                        'grade': i[3],
                        'semester': i[4],
                        'year': i[5],
                    }
                )

        std_study = []
        for i, v in enumerate(std_dict["data"]):
            grade = []
            for m, n in enumerate(std_dict["data"]):
                if v['sub_id'] == n['sub_id']:
                    grade.append([n['grade'], n['semester'], n['year']])
            std_study.append([v['sub_id'], grade])

        true_std = []
        for i in std_study:
            if i not in true_std:
                true_std.append(i)
        
        grade = ['A', 'B+', 'B', 'C+', 'C', 'D+', 'D', 'P','N']
        grade_pass =['A', 'B+', 'B', 'C+', 'C', 'D+', 'D', 'P']

        sub_and_grade = []
        for i, v in enumerate(true_std):
            for j, k in enumerate(v[1]):
                if k[0] in grade:
                    sub_and_grade.append([v[0], k])

        
        sub_edit = []
        for i in sub_and_grade:
            for j in subject:

                if i[0] == j[1]:
                    if j[2] == 'หมวดวิชาศึกษาทั่วไป':
                        tmp = int(i[1][2])+543
   
                        edit_gen_use = edit_use(tmp, n_edit_gen, edit_gen)
   
                        if [i[0]+'-'+edit_gen_use[2]+edit_gen_use[3], i[1]] not in sub_edit:
                            sub_edit.append(
                                [i[0]+'-'+edit_gen_use[2]+edit_gen_use[3], i[1]])
  
                    elif j[2] == 'หมวดวิชาเฉพาะ':
                        edit_use_ = edit_use(a, n_edit_, edit_)
       
                        if [i[0]+'-'+course, i[1]] not in sub_edit:
                
                            sub_edit.append([i[0]+'-'+course, i[1]])
                    
                    elif j[2] == 'หมวดวิชาเลือกเสรี':

                        tmp = int(i[1][2])+543
   
                        edit_gen_use = edit_use(tmp, n_edit_gen, edit_gen)

                        if [i[0]+'-'+edit_gen_use[2]+edit_gen_use[3], i[1]] not in sub_edit:

                            sub_edit.append(
                                [i[0]+'-'+edit_gen_use[2]+edit_gen_use[3], i[1]])
        # for i in sub_edit:
        #     print(i)
           

        true_sub_edit = []
        for i in sub_edit:

            if i not in true_sub_edit:
                true_sub_edit.append(i)
        

        only_sub = []
        for i in subject:
            # if i[0] == '02714102-59':
            #     print('found')
            only_sub.append(i[0])



        only_sub_edit = []
        for i in true_sub_edit:
            if i[0] in only_sub:
                only_sub_edit.append(i)

        # for i in only_sub_edit:
        #     if i[0]=='02714102-59':
        #         print(i)

        graded_sub = []
        for i in only_sub_edit:
            if i[1][0] in grade_pass:
                graded_sub.append(i[0])



        pre_group = []
        for i, v in enumerate(only_sub_edit):
            group = []
            subject = v[0]
            pre_group.append([subject, find_prerequisite(
                pre_dict['data'], subject, group)])



        group_ = []
        for i in pre_group:
            group_.append([i[0], group_pre_sub(i[1])])


        result_ = []
        tmp_result = []
        for i in group_:
            
            result_.append([student, i[0], compare(i[1], graded_sub)])
            tmp_result.append(i[0])
            
        
        
        for i in result_:
            # if i[1] == '01418232-60':
                cur.execute("SELECT * FROM prerequisite_info WHERE sub_code = %s", (i[1]))
                pre = cur.fetchall()
                
                if pre != ():
                    # print('---pre---')
                    # print(pre)
                    calstatus=[]
                    # print(i[1])
                    for k in pre:
                        # print(k)
                        calpass=[]
                        n=0
                        while n<=2:
                           
                                # print('y')
                                if k[2+n] == 'None':
                                    calpass.append(1)
                                    # print('None')
                                else:
                                    if k[2+n] in tmp_result:
                                        for l in result_:
                                            if k[2+n] == l[1]:
                                                # print(f'{k[2+n]}  {l[2]}')
                                                if l[2]=='PASS':
                                                    calpass.append(1)
                                                elif l[2] == 'NOT PASS':
                                                    calpass.append(0)
                                    else:
                                        # print('n')
                                        calpass.append(0)
                                n+=1
                        # print(calpass)
                        if 0 in calpass:
                            calstatus.append(0)
                        elif 0 not in calpass:
                            calstatus.append(1)
                    # print('---------------')
                    # print(calstatus)
                    if 1 in calstatus:
                        i[2] = 'PASS'
                    elif 1 not in calstatus:
                        i[2] = 'NOT PASS'
                    # print(i)
                elif pre is None:
                    i[2] = 'PASS'

        for i in result_:     
            for j in true_sub_edit:
                    if i[1] == j[0] and j[1][0] == 'N' and i[2] != 'NOT PASS':
                        i[2] = 'INPROGRESS'
                    elif i[1] == j[0] and j[1][0] == 'N' and i[2] == 'NOT PASS':
                        i[2] = 'INPROGRESS'
                    elif i[1] == j[0] and j[1][0] in grade_pass and i[2] == 'NOT PASS':
                        i[2] = 'UNCOMMON'
            

        # for i in result_:
        #     if i[1] == '02714102-59':
        #      print(i)
        
       
                    
        # for i in result_:
        #     print(i)        
        # print(len(result_))
        
        old = []
        cur.execute("SELECT * FROM progress_info WHERE std_id = %s and admin_id = %s", (student,self.admin_id))
        old = cur.fetchone()

        if old is not None:
            cur.execute(
                "UPDATE progress_info SET deleted = 1 WHERE std_id = %s and admin_id = %s", (student,self.admin_id))
            db.commit()
        for i in result_:
  
            sql = "INSERT INTO progress_info (std_id, sub_code, status,date,time,admin_id) VALUES (%s,%s,%s,%s,%s,%s)"
            val = (i[0], i[1], i[2], self.current_day, self.current_time,self.admin_id)
            cur.execute(sql, val)
            db.commit()


# current_day = '04/04/2023'
# current_time = '18:12:55'
# checkp = checkPRE('6221601282', current_day, current_time,1)
# checkp.check_pre()
