import pymysql


def connect_db(dbname):
    mydb = pymysql.connect(
        host="10.36.16.177",
        user="root",
        port=3306,
        password="0948544473Za@",
        database="graduation_requirments_system"
    
    )
    return mydb


class checkcond():
    def __init__(self, std, current_day, current_time,admin_id):
        self.std = std
        self.current_day = current_day
        self.current_time = current_time
        self.admin_id = admin_id

    def check_cond(self):
        student = str(self.std)
        # use_grade = ['A', 'B+', 'B', 'C+', 'C', 'D', 'D+']

        db = connect_db('graduation_requirments_system')
        cur = db.cursor()

        cur.execute("SELECT * FROM student_info WHERE std_id = %s and admin_id = %s", (student,self.admin_id))
        std = cur.fetchone()

        course_id = str(std[3])

        cur.execute(
            "SELECT * FROM condition_info WHERE course_id = %s", course_id)
        cond = cur.fetchall()

        cur.execute("SELECT * FROM progress_info WHERE std_id = %s AND deleted = 0 AND date = %s AND time = %s AND (status ='PASS' OR status ='INPROGRESS' OR status = 'UNCOMMON') and admin_id = %s",
                    (student, self.current_day, self.current_time,self.admin_id))
        prog = cur.fetchall()

        cur.execute("SELECT * FROM study_info WHERE std_id = %s AND deleted = 0 AND date = %s AND time = %s AND admin_id = %s",
                    (student, self.current_day, self.current_time,self.admin_id))
        study = cur.fetchall()

        cond_dict = {"data": []}
        for i in cond:
            cond_dict["data"].append(
                {
                    'con_id': i[0],
                    'section': i[1],
                    'group': i[2],
                    'subject_group': i[3],
                    'subgroup': i[4],
                    'credits': i[5],
                    'course': i[6],
                }
            )

        sub_prog = []
        for i in prog:
            cur.execute("SELECT * FROM subject_info WHERE sub_code = %s", i[1])
            sub = cur.fetchone()
            sub_prog.append({
                'sub_code': sub[0],
                'sub_id': sub[1],
                'section': sub[2],
                'group': sub[3],
                'subject_group': sub[4],
                'subgroup': sub[5],
                'subject_name': sub[6],
                'credit': sub[7],
                'affiliation': sub[8],
            })


        study_dict = []
        for i in study:
            study_dict.append({
                'std_id': i[1],
                'sub_id': i[2],
                'grade': i[3],
            })


        cond_sub = []
        count_condition = []
        check = []
        for i in cond_dict["data"]:
            # subject=[]
            count = 0
            count_credit = 0
            if i['subject_group'] == 'ภาษาต่างประเทศ' and i['subgroup'] == '1':
                lang = []
                lang_ = []
                count_lang = []
                sub_lang = []
                for j in sub_prog:
                    if j['subject_group'] == 'ภาษาต่างประเทศ':
                        
                        for stu in study_dict:
                            if j['sub_id'] == stu['sub_id']:
                                # and stu['grade']!='N'
                                if stu['grade'] != 'P':  # and stu['grade'] != 'N'
                                    # print(j)
                                    if j['subgroup'] in lang_:
                                        for x, y in enumerate(lang):
                                            print(y)
                                            if j['subgroup'] == y['lang']:
                                                if j['sub_code'] not in check:
                                                    sub_lang.append(j)
                                                    # check.append(j['sub_code'])
                                                    y['count'] += 1
                                                    y['credit'] += int(j['credit'])
                                        # print(i)
                                        # print(j)
                                    if j['subgroup'] not in lang_ and j['subgroup'] != 'None':
                                        if j['sub_code'] not in check:
                                            sub_lang.append(j)
                                            # check.append(j['sub_code'])
                                            lang_.append(j['subgroup'])
                                            lang.append(
                                                {'lang': j['subgroup'], 'count': 1, 'credit': int(j['credit'])})
                                            # print(i)
                                            # print(j)
                print(lang)
                # print('\n')
                comp = []
                tmp = 0
                for inx, val in enumerate(lang):
                    if val['credit'] > tmp:
                        comp = val
                        tmp = val['credit']
                # print(comp)
                # print('\n')
                # print(sub_lang)
                if comp == []:
                    count_condition.append([i['con_id'], 0, 0])
                else:
                    for sub in sub_lang:
                        if sub['subgroup'] == comp['lang']: #ตรวจสอบ น่าจะผิดตรงนี้แหละ
                            
                            if sub['sub_code'] not in check:
 
                                if count_credit < int(i['credits']) and (count_credit+int(sub['credit']))-int(i['credits']) <= 1:
                    
                                    
                                    check.append(sub['sub_code'])
                                    # subject.append(sub)
                                    cond_sub.append([i['con_id'], sub['sub_code'], sub['sub_id'], sub['section'], sub['group'],
                                                    sub['subject_group'], sub['subgroup'], sub['subject_name'], sub['credit']])
                                    count += 1


                                    count_credit += int(sub['credit'])

                    count_condition.append([i['con_id'], count, count_credit])
                    # cond_sub.append([i['con_id'],subject])

            elif i['section'] == 'หมวดวิชาศึกษาทั่วไป' and i['group'] == 'None' and i['subject_group'] == 'None' and i['subgroup'] == 'None':
                for j in sub_prog:

                    if i['section'] == j['section']:
                        for stu in study_dict:
                            if j['sub_id'] == stu['sub_id']:
                                if stu['grade'] != 'P':  # and stu['grade'] != 'N'
                                    if j['sub_code'] not in check:
                                        if count_credit < int(i['credits']) and (count_credit+int(j['credit']))-int(i['credits']) <= 1:
                                            check.append(j['sub_code'])
                                            # subject.append(j)
                                            cond_sub.append([i['con_id'], j['sub_code'], j['sub_id'], j['section'], j['group'],
                                                            j['subject_group'], j['subgroup'], j['subject_name'], j['credit']])
                                            count += 1


                                            count_credit += int(j['credit'])


                count_condition.append([i['con_id'], count, count_credit])
                # cond_sub.append([i['con_id'],subject])
            elif i['section'] != 'หมวดวิชาเลือกเสรี' and i['subject_group'] != 'ภาษาต่างประเทศ':
                for j in sub_prog:
                    if i['section'] == j['section'] and i['group'] == j['group'] and i['subject_group'] == j['subject_group']:
                        for stu in study_dict:
                            if j['sub_id'] == stu['sub_id']:
                                if stu['grade'] != 'P':  # and stu['grade'] != 'N'
                                    if j['sub_code'] not in check:
                                        if count_credit < int(i['credits']) and (count_credit+int(j['credit']))-int(i['credits']) <= 1:
                                            check.append(j['sub_code'])
                                            # subject.append(j)
                                            cond_sub.append([i['con_id'], j['sub_code'], j['sub_id'], j['section'], j['group'],
                                                            j['subject_group'], j['subgroup'], j['subject_name'], j['credit']])
                                            count += 1

                                            count_credit += int(j['credit'])


                count_condition.append([i['con_id'], count, count_credit])
                # cond_sub.append([i['con_id'],subject])
        count = 0
        count_credit = 0
        for j in sub_prog:
            for stu in study_dict:
                if j['sub_id'] == stu['sub_id']:
                    if stu['grade'] != 'P':
                        if j['sub_code'] not in check:

                            check.append(j['sub_code'])
                            # subject.append(j)
                            for i in cond_dict["data"]:
                                if i['section'] == 'หมวดวิชาเลือกเสรี':
                                    cond_sub.append([i['con_id'], j['sub_code'], j['sub_id'], j['section'], j['group'],
                                                    j['subject_group'], j['subgroup'], j['subject_name'], j['credit']])
                            count += 1

                            count_credit += int(j['credit'])

        for i in cond_dict["data"]:
            if i['section'] == 'หมวดวิชาเลือกเสรี':
                count_condition.append([i['con_id'], count, count_credit])

        for i in count_condition:
            for j in cond_dict['data']:
                if i[0] == j['con_id']:
                    if i[2]-int(j['credits']) >= 0:
                        i.append('PASS')
                    else:
                        i.append('NOT PASS')

### sql
        old = []
        for i in cond_sub:
            cur.execute(
                "SELECT * FROM sub_in_cond_info WHERE std_id = %s AND deleted = 0 and admin_id = %s", (student, self.admin_id))
            old.append(cur.fetchone())
            # print(old)
            if old != []:
                cur.execute(
                    "UPDATE sub_in_cond_info SET deleted = 1 WHERE std_id = %s and admin_id = %s", (student, self.admin_id))

        for i in cond_sub:
            # print(i)
            sql = "INSERT INTO sub_in_cond_info (std_id, con_id, sub_code,date,time,deleted,admin_id) VALUES (%s,%s,%s,%s,%s,%s,%s)"
            val = (student, int(i[0]), i[1],
                   self.current_day, self.current_time, 0, self.admin_id)
            cur.execute(sql, val)
            db.commit()

        # print("-"*130)
        old = []
        cur.execute(
            "SELECT * FROM cond_progress WHERE std_id = %s AND deleted = 0 and admin_id = %s", (student, self.admin_id))
        old.append(cur.fetchone())
        # print(old)
        if old != []:
            cur.execute(
                "UPDATE cond_progress SET deleted = 1  WHERE std_id = %s and admin_id = %s", (student, self.admin_id))
        for i in count_condition:
            # print(i)
            sql = "INSERT INTO cond_progress (std_id, con_id, credits, status,date,time,deleted,admin_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
            val = (student, int(i[0]), i[2], i[3],
                   self.current_day, self.current_time, 0, self.admin_id)
            cur.execute(sql, val)
            db.commit()
### sql


# current_day='16/03/2023'
# current_time='00:55:00'
# checkc = checkcond('6221601266', current_day, current_time)
# checkc.check_cond()
