from bs4 import BeautifulSoup

class ReadHtml():
    def __init__(self,file):
        self.file = file
        self.soup = BeautifulSoup(open(self.file, mode='r',encoding ="cp874"),'html.parser')
        self.test =self.soup.find_all('span',attrs={'style': 'font-size:10.0pt;mso-fareast-font-family:"Times New Roman"'})
        self.id =self.soup.find_all("span",attrs={'style': '''font-size:13.5pt;mso-fareast-font-family:
    "Times New Roman"'''})
        self.name_surname =self.soup.find_all('span',attrs={'lang': 'TH','style':'''font-size:13.5pt;
    mso-fareast-font-family:"Times New Roman";color:#006633'''})
        self.group=[]
        self.group2=[]
        self.std_id=""
        self.count=0
        # for i,v in enumerate(self.test):
        #     print(v.get_text(strip=True).strip())
    def ReadHtml(self):
        self.std_id = self.id[0].text
        self.name = self.name_surname[0].text.split()[0]
        self.surname = self.name_surname[0].text.split()[1]
        for i in self.test:
            if i.text not in ["Course Code","Course Title","Grade","Credit"] and 'sem. G.P.A.' not in i.text and "cum. G.P.A." not in i.text and i.text !=" " and ".\n" not in i.text and '. ' not in i.text:
                if 'Semester' in i.text:
                    k=i.text
                    j=k.split()
                    if 'First' in j:
                        sem='1'
                        y=j[2]
                    elif 'Second' in j:
                        sem='2'
                        y=j[2]
                elif 'Summer' in i.text:
                    tmp=int(j[2])+1
                    sem='1'
                    y=tmp
                else:
                    self.count+=1
                    self.group.append(i.text)
                    if self.count ==1:
                        self.group.append('subject name')
                    if self.count ==3:
                        self.group.append(sem)
                        self.group.append(y)
                        self.group2.append(self.group)
                        self.group=[]
                        self.count=0
        # for i in self.group2:
        #     print(i)
        # print(self.name)
        # print(self.surname)
        return(self.group2,self.std_id,self.name,self.surname)
       
# if __name__ == "__main__":
#     test = ReadHtml('./e2239T8EB3QD.html')
#     study = test.ReadHtml()
    # print(test.ReadHtml())