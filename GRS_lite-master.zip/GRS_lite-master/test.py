# import readhtml
# file = "./1282.html"
# html_read = readhtml.ReadHtml(file)
# study= html_read.ReadHtml()
# print(study)


# import off_readhtml
# file = "./profile.html"
# html_read = off_readhtml.ReadHtml(file)
# study= html_read.ReadHtml()
# print(study)

def find_edit(edit_):
    n = []
    for i in edit_:
        m = []
        for j in range(int(i), int(i)+5):
            m.append(j)
        n.append(m)
    return (n)


def edit_use(num, n_edit, edit_):
    for i, v in enumerate(n_edit):
        if int(num) in v:
            return (edit_[i])


edit_ = [2559,2564]
n_edit = find_edit(edit_)
edit = edit_use(2020+543, n_edit, edit_)
print(n_edit)
print(str(edit)[2]+str(edit)[3])



