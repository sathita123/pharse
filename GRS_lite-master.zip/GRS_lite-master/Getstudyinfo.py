
import pymysql
from checkpre import find_edit, edit_use


def connect_db(dbname):
    mydb = pymysql.connect(
        host="10.36.16.177",
        user="root",
        port=3306,
        password="0948544473Za@",
        database="graduation_requirments_system"
    )
    return mydb


def cal_N(group):
    gradeN = 0
    for i in group:

        for j in i[3]:

            if j[0] == 'N':
                gradeN += int(i[2])


    return gradeN


def find_prerequisite(pre, subject, group, graded_sub):
    for j in pre:
        if j[0] == subject:

            for k in j[1]:

                for m in k:
                    if m != 'None':
                        for i in graded_sub:
                            if m == i[0]:

                                if [m, i[1], i[2], i[3]] not in group:
                                    group.append([m, i[1], i[2], i[3]])
                        find_prerequisite(pre, m, group, graded_sub)
    return group
#
# std_id='6221601894'


def get_cond_progress(std_id, data_date, data_time,admin_id):

    db = connect_db('graduation_requirments_system')
    cur = db.cursor()
    

    cur.execute(
        "SELECT * FROM student_info WHERE std_id = %s AND deleted = 0 and admin_id = %s ", (std_id,admin_id))
    std = cur.fetchone()

    std_ = {
        'std_id': std[0],
        'name': std[1],
        'surname': std[2],
        'course_id': std[3]
    }
    cur.execute(
        "SELECT * FROM course_info WHERE course_id = %s AND deleted = 0", std_['course_id'])
    course = cur.fetchone()
    course_ = {
        'course_id': course[0],
        'course_name': course[1]
    }
    std_['course_name'] = course_['course_name']

    cur.execute("SELECT * FROM cond_progress WHERE std_id = %s And date = %s AND time = %s AND deleted = 0 and admin_id = %s",
                (std_id, data_date, data_time,admin_id))
    cond = cur.fetchall()


    cur.execute("SELECT * FROM sub_in_cond_info WHERE std_id = %s And date = %s AND time = %s AND deleted = 0 and admin_id = %s",
                (std_id, data_date, data_time,admin_id))
    sub_in_cond = cur.fetchall()


    cur.execute("SELECT * FROM subject_info")
    subject = cur.fetchall()


    cur.execute("SELECT * FROM condition_info WHERE course_id = %s",
                std_['course_id'])
    cond_info = cur.fetchall()

    cond_dict = []
    for i in cond_info:
        cond_dict.append(
            {
                'con_id': i[0],
                'section': i[1],
                'group': i[2],
                'subject_group': i[3],
                'subgroup': i[4],
                'credits': i[5],
                'course': i[6],
            }
        )

    allcredit = 0


    prog = []
    for i in cond:
        for j in cond_dict:
            if i[1] == j['con_id']:
                prog.append([i[1], j['section'], j['group'], j['subject_group'],
                            j['subgroup'], i[2], int(j['credits']), i[3]])

#=======================================================================================================================================#
    study = []
    cur.execute("SELECT * FROM study_info WHERE std_id = %s And date = %s AND time = %s AND deleted = 0 and admin_id = %s",
                (std_id, data_date, data_time,admin_id))
    g = cur.fetchall()
    for i in g:
        study.append([i[2], [i[3], i[4], i[5]]])


    std_study = []
    for i in study:
        gg = []
        for j in study:
            if i[0] == j[0]:
                gg.append([j[1][0], j[1][1], j[1][2]])
        if [i[0], gg] not in std_study:
            std_study.append([i[0], gg])



    grade = ['A', 'B+', 'B', 'C+', 'C', 'D+', 'D', 'P', 'N']

    sub_and_grade = []
    for v in std_study:
        for k in v[1]:
            if k[0] in grade:
                sub_and_grade.append([v[0], k])



    prog_group = []
    for i in prog:
        count_study = 0
        count_all = 0
        ispass_list = []
        con_id = []
        for j in prog:
            if i[1] == j[1] and i[2] == j[2]:
                count_study += int(j[5])
                count_all += int(j[6])
                ispass_list.append(j[7])
                con_id.append(j[0])
        ispass = ''
        if 'NOT PASS' in ispass_list:
            ispass = 'NOT PASS'
        else:
            ispass = "PASS"
        if [i[1], i[2], count_study, count_all, ispass, con_id] not in prog_group:
            prog_group.append(
                [i[1], i[2], count_study, count_all, ispass, con_id])
    # for i in prog_group:
    #     print(i)


    sub_in_cond_list = []
    for i in prog_group:
        sub = []
        for j in i[5]:
            for k in sub_in_cond:
                if j == k[1]:

                    for l in subject:
                        if k[2] == l[0]:
                            for m in sub_and_grade:
                                if l[1] == m[0]:
                                    sub_info = [l[0], l[6], l[7], m[1][0]]
                    sub.append(sub_info)
        sub_in_cond_list.append([i, sub])

#=======================================================================================================================================#
    sec_prog = []
    for i in prog:
        allcredit += int(i[5])
        if i[1] not in sec_prog:
            sec_prog.append(i[1])



    sec_cond = []
    for i in sec_prog:
        count = 0
        for j in cond_dict:
            if i == j['section']:
                count += int(j['credits'])
        sec_cond.append([i, count])


    sec_ = []
    for i in sec_prog:
        count = 0
        for j in prog:
            if i == j[1]:
                count += int(j[5])
        sec_.append([i, count])


    prog_ = []
    sec_header = []
    for j in sec_:
        group = []
        for i in prog:
            text = ''
            if j[0] == i[1]:

                if i[1] != 'หมวดวิชาเลือกเสรี' and i[2] == 'None':
                    text = i[1]
                    group.append([text, int(i[5]), i[6], i[7]])
                elif i[2] != 'None' and i[3] == 'None':
                    text = i[2]
                    group.append([text, int(i[5]), i[6], i[7]])
                elif i[3] != 'None':
                    text = i[2]+' '+i[3]

                    group.append([text, int(i[5]), i[6], i[7]])
        check_group = []
        for i in group:
            if i[3] not in check_group:
                check_group.append(i[3])
        for k in sec_cond:
            if j[0] == k[0]:
                if int(j[1]) < int(k[1]) or 'NOT PASS' in check_group:

                    ispass = 'NOT PASS'
                    all = k[1]
                elif (int(j[1]) > int(k[1]) or int(j[1]) == int(k[1])) and 'NOT PASS' not in check_group:
                    ispass = 'PASS'

                    all = k[1]
        sec_header = [j[0], j[1], all, ispass]
        prog_.append([sec_header, group])


#=======================================================================================================================================#
    use = []
    for i in prog_:
        group = []
        for j in sub_in_cond_list:
            if i[0][0] == j[0][0]:
                if j[0][1] == 'None':
                    tmp = j[0][0]
                else:
                    tmp = j[0][1]
                group.append([[tmp, j[0][2], j[0][3], j[0][4]], j[1]])
        use.append([i[0], group])


#=======================================================================================================================================#

    count_all_study = 0
    for i in sec_:
        count_all_study += int(i[1])


    count_credit_cond = 0
    for i in cond_dict:
        count_credit_cond += int(i['credits'])


    needmore = 0
    for i in prog:
        tmp = int(i[6])-int(i[5])
        if tmp >= 0:
            needmore += tmp
        elif tmp < 0:
            needmore += 0



    use_dict = {'data': []}
    for i in use:
        group = []
        for j in i[1]:
            subject_group = []
            for k in j[1]:
                subject_group.append(k)
            group.append({'group': j[0],
                          'subject': subject_group
                          })
        use_dict['data'].append({
            'section': i[0],
            'group_sub': group,
        })

    # for i in use:
    #     print(i)
    data = {
        'std_info': [std_],
        'count_all_study': count_all_study,
        'need_more': needmore,
        'condition_progress': use_dict,
        'for_other_func': use
    }
    return (data)


def get_study_progress(std_id, data_date, data_time,admin_id):
    db = connect_db('graduation_requirments_system')
    cur = db.cursor()
    
    # print(sub_uncom)
    cur.execute(
        "SELECT * FROM student_info WHERE std_id = %s AND deleted = 0 and admin_id = %s", (std_id,admin_id))
    std = cur.fetchone()
    print(std)
    std_ = {
        'std_id': std[0],
        'name': std[1],
        'surname': std[2],
        'course_id': std[3]
    }
    cur.execute(
        "SELECT * FROM course_info WHERE course_id = %s AND deleted = 0", std_['course_id'])
    course = cur.fetchone()
    course_ = {
        'course_id': course[0],
        'course_name': course[1]
    }



    cur.execute("SELECT * FROM condition_info WHERE course_id = %s",
                std_['course_id'])
    cond_info = cur.fetchall()

    cond_dict = []
    for i in cond_info:
        cond_dict.append(
            {
                'con_id': i[0],
                'section': i[1],
                'group': i[2],
                'subject_group': i[3],
                'subgroup': i[4],
                'credits': i[5],
                'course': i[6],
            }
        )

    cur.execute("SELECT * FROM sub_in_cond_info WHERE std_id = %s  And date = %s AND time = %s AND deleted = 0 and admin_id = %s",
                (std_id, data_date, data_time,admin_id))
    sub_cond = cur.fetchall()

    cur.execute("SELECT * FROM subject_info")
    allsubject = cur.fetchall()

    subject = []
    for i in sub_cond:
        cur.execute("SELECT * FROM subject_info WHERE sub_code = %s", i[2])
        sub = cur.fetchone()
        subject.append(
            {
                'sub_code': sub[0],
                'sub_id': sub[1],
                'subject_name': sub[6],
                'credit': sub[7],
            }
        )

    edit_ = []
    for i, v in enumerate(allsubject):
        if v[2] != 'หมวดวิชาศึกษาทั่วไป':
            if v[9] not in edit_:
                edit_.append(v[9])

    edit_gen = []
    for i, v in enumerate(allsubject):
        if v[2] == 'หมวดวิชาศึกษาทั่วไป':
            if v[9] != 'None' and v[9] not in edit_gen:
                edit_gen.append(v[9])


    n_edit_ = find_edit(edit_)

    n_edit_gen = find_edit(edit_gen)


    study = []
    for i in subject:
        cur.execute("SELECT * FROM study_info WHERE std_id = %s and sub_id = %s And date = %s AND time = %s AND deleted = 0 and admin_id = %s",
                    (std_id, i['sub_id'], data_date, data_time,admin_id))
        g = cur.fetchall()
        for i in g:
            study.append([i[2], [i[3], i[4], i[5]]])

    std_study = []
    for i in study:
        g = []
        for j in study:
            if i[0] == j[0]:
                g.append([j[1][0], j[1][1], j[1][2]])
        std_study.append([i[0], g])

    true_std = []
    for i in std_study:
        if i not in true_std:
            true_std.append(i)


    year = []
    for i in true_std:
        for j in i[1]:
            if int(j[2]) not in year:
                year.append(int(j[2]))
    year = sorted(year)


    grade = ['A', 'B+', 'B', 'C+', 'C', 'D+', 'D', 'P']

    sub_grade = []
    for i, v in enumerate(true_std):
        for j, k in enumerate(v[1]):
            if k[0] in grade:
                sub_grade.append([v[0], k])



    a = '25'+std_id[0]+std_id[1]

    course_id = str(std_['course_id']).split('-')[1]

    sub_edit = []
    for i in true_std:
  
        for j in allsubject:
            if i[0] == j[1]:
                if j[2] == 'หมวดวิชาศึกษาทั่วไป':
                    tmp = int(i[1][0][2])+543

                    edit_gen_use = edit_use(tmp, n_edit_gen, edit_gen)

                    if [i[0]+'-'+edit_gen_use[2]+edit_gen_use[3], i[1]] not in sub_edit:
                        sub_edit.append(
                            [i[0]+'-'+edit_gen_use[2]+edit_gen_use[3], i[1]])

                elif j[2] == 'หมวดวิชาเฉพาะ':
                    # edit_use_ = edit_use(a, n_edit_, edit_)
                    
                    sub_code_new = i[0]+'-'+course_id
                    if [sub_code_new, i[1]] not in sub_edit:
                        sub_edit.append([sub_code_new, i[1]])
                    
                elif j[2] == 'หมวดวิชาเลือกเสรี':
                        # print(i)
                        tmp = int(i[1][0][2])+543
   
                        edit_gen_use = edit_use(tmp, n_edit_gen, edit_gen)

                        if [i[0]+'-'+edit_gen_use[2]+edit_gen_use[3], i[1]] not in sub_edit:

                            sub_edit.append(
                                [i[0]+'-'+edit_gen_use[2]+edit_gen_use[3], i[1]])


    sub_and_grade = []
    for i in sub_cond:
        for j in subject:
            if i[2] == j['sub_code']:
                for k in sub_edit:
                    if j['sub_code'] == k[0]:
                        sub_and_grade.append({
                            'con_id': int(i[1]),
                            'sub_code': i[2],
                            'subject_name': j['subject_name'],
                            'credit': j['credit'],
                            'grade': k[1]
                        })

    
    allcredit = 0
    sec = []
    for i in cond_dict:
        allcredit += int(i['credits'])
        if i['section'] not in sec:
            sec.append(i['section'])

    cond_list = get_cond_progress(std_id, data_date, data_time,admin_id)


    section_group = []
    section_dict = {'data': []}

    for i in cond_list['for_other_func']:
        tmp_sec = ''
        tmp_sec = str(i[0][1])+'/'+str(i[0][2])
        section = [i[0][0], tmp_sec]
        group_group = []
        for j in i[1]:
            tmp_group = ''
            tmp_group = str(j[0][1])+'/'+str(j[0][2])
            group = [j[0][0], tmp_group]
            subject_group = []
            for k in j[1]:
                for m in sub_and_grade:
                    if k[0] == m['sub_code']:
                        grade = []

                        for l in m['grade']:
                            term = ''
                            if l[1] == '1':
                                term = '0'  # 0=ต้น
                            else:
                                term = '1'  # 1=ปลาย
                            pi = ''
                            for ninx, nval in enumerate(year):
                                if str(l[2]) == str(nval):
                                    pi = 'ปี'+str(ninx+1)+'/' + \
                                        str(int(l[2])+543)
                            grade.append([l[0], term, pi])
                        subject_ = {
                            'education_id': k[0], 'education_name': k[1], 'credit': k[2], 'grade': l[0], 'class_grade': pi, 'term': term}

                subject_group.append(subject_)


            group_group.append(
                {'group': group, 'subject_group': subject_group})

        section_group.append([section, group_group])
        section_dict['data'].append({
            'section': section,
            'sub_n_grade': group_group
        })
    #ตรวจสอบข้อมูล
    section_group = []
    for i in cond_list['for_other_func']:
        tmp_sec = ''
        tmp_sec = str(i[0][1])+'/'+str(i[0][2])

        section_ = [i[0][0], tmp_sec]
        group_group_ = []
        for j in i[1]:
            tmp_group = ''
            tmp_group = str(j[0][1])+'/'+str(j[0][2])

            group_ = [j[0][0], tmp_group]
            subject_group_ = []
            for k in j[1]:
                for m in sub_and_grade:
                    if k[0] == m['sub_code']:

                        subject_1 = [k[0], k[1], k[2], m['grade']]
                subject_group_.append(subject_1)

            group_group_.append([group_, subject_group_])

        section_group.append([section_, group_group_])

    for i in section_group:

        for j in i[1]:

            allN = cal_N(j[1])

            if allN != 0:
                j[0].append(str(allN))
            else:
                j[0].append("")

    for i in section_group:

        sec_N = 0
        for j in i[1]:
            if j[0][2] != "":
                sec_N += int(j[0][2])

        if sec_N != 0:
            i[0].append(str(sec_N))
        else:
            i[0].append("")


    for i in section_dict['data']:
       
        sec_N = 0
        for j in i['sub_n_grade']:
         
            allN = 0
            for k in j['subject_group']:
               
                if k['grade'] == 'N':
                    allN += int(k['credit'])
            if allN != 0:
                j['group'].append(str(allN))
            else:
                j['group'].append("")
            sec_N += allN
        if sec_N != 0:
            i['section'].append(str(sec_N))
        else:
            i['section'].append("")
        

    sub_prog_info = {
        'data': section_dict['data'],
        'course_name': course_['course_name'],
        'allcredit': allcredit,
        'for_other_func': section_group
    }

    return (sub_prog_info)


def get_study_info_for_teacher(std_id, data_date, data_time,admin_id):  # ()

    db = connect_db('graduation_requirments_system')
    cur = db.cursor()
    cur.execute("SELECT * FROM prerequisite_info")
    pre = cur.fetchall()

    # cur.execute("SELECT * FROM progress_info WHERE std_id=%s And date = %s AND time = %s AND deleted = 0 AND (status ='PASS' OR status ='INPROGRESS' or status ='UNCOMMON' ) and admin_id = %s",
    #             (std_id, data_date, data_time,admin_id))
    # prog = cur.fetchall()
     

    pre_dict = {"data": []}
    for i in pre:
        pre_dict["data"].append(
            {
                'pregroup_id': i[0],
                'sub_code': i[1],
                'prerequisite': [i[2], i[3], i[4]],
            }
        )
    cur.execute("SELECT * FROM progress_info WHERE std_id=%s And date = %s AND time = %s AND deleted = 0 AND (status ='PASS' OR status ='INPROGRESS' or status ='UNCOMMON' ) and admin_id = %s",
                (std_id, data_date, data_time,admin_id))
    prog = cur.fetchall()

    cur.execute("SELECT * FROM progress_info WHERE std_id=%s And date = %s AND time = %s AND deleted = 0 AND status ='UNCOMMON' and admin_id = %s",
                (std_id, data_date, data_time,admin_id))
    uncom = cur.fetchall()
    sub_uncom = []
    for i in uncom:
        sub_uncom.append(i[1])
    # print(prog)

    cur.execute("SELECT * FROM subject_info")
    sub = cur.fetchall()

    cur.execute("SELECT * FROM study_info WHERE std_id=%s And date = %s AND time = %s AND deleted = 0 and admin_id = %s",
                (std_id, data_date, data_time,admin_id))
    study = cur.fetchall()

    grade = ['A', 'B+', 'B', 'C+', 'C', 'D+', 'D', 'P']
    graded_sub = []
    for i in prog:
        g = []
        g.append(i[1])
        for j in sub:
            if i[1] == j[0]:
           
                for k in study:
                    if j[1] == k[2] and k[3] in grade:
                        g.append(k[3])
                        g.append(k[4])
                        g.append(k[5])
        graded_sub.append(g)



    study_info = get_study_progress(std_id, data_date, data_time,admin_id)

    # for i in study_info['for_other_func']:  # ตรวจสอบว่าเป็นกลุ่มเดียวกันหรือไม่
    #     print(i)

    study_sub_code = []
    year = []
    for i in study_info['for_other_func']:
        for j in i[1]:
            for k in j[1]:
              
                study_sub_code.append(k[0])
                for l in k[3]:
                    if l[2] not in year:
                        year.append(l[2])


# ===========================================================================================================================
    pre_group = []
    for i in pre_dict['data']:
        group = []
        for j in pre_dict['data']:
            if i['sub_code'] == j['sub_code']:
                group.append(j['prerequisite'])
        if [i['sub_code'], group] not in pre_group:
            pre_group.append([i['sub_code'], group])

    

    for i in study_info['for_other_func']:
        for j in i[1]:
            
            for ik, k in enumerate(j[1]):
                # print(k[0])                  #eueu
                tmp = []
                n = len(k[3])
                while n > 0:
                    tmp.append(k[3][n-1])
                    n -= 1

                for inx_each, val_each in enumerate(tmp):
                    # print(val_each)
                    # print(tmp)
                    if val_each[0] == 'A':
                        tmp[inx_each][0] = str(val_each[0])+' (4.00)'
                    elif val_each[0] == 'B+':
                        tmp[inx_each][0] = str(val_each[0])+' (3.50)'
                    elif val_each[0] == 'B':
                        tmp[inx_each][0] = str(val_each[0])+' (3.00)'
                    elif val_each[0] == 'C+':
                        tmp[inx_each][0] = str(val_each[0])+' (2.50)'
                    elif val_each[0] == 'C':
                        tmp[inx_each][0] = str(val_each[0])+' (2.00)'
                    elif val_each[0] == 'D+':
                        tmp[inx_each][0] = str(val_each[0])+' (1.50)'
                    elif val_each[0] == 'D':
                        tmp[inx_each][0] = str(val_each[0])+' (1.00)'
                    elif val_each[0] in 'WNF':
                        # print(tmp[inx_each][0])
                        tmp[inx_each][0] = str(val_each[0])+' (-)'
                    for subi in sub_uncom:
                        if k[0] == subi:
                            # print('eiei')
                            tmp[inx_each][0] = str(val_each[0])+' (UNCOMMON)'
                    for inx_y, val_y in enumerate(year):
                        if val_each[2] == val_y:
         
                            tmp[inx_each][2] = 'ปี' + \
                                str(inx_y+1)+'/'+str(int(val_y)+543)


                

    use_dict = {'data': []}
    for i in study_info['for_other_func']:

        tmp = []
        for j in i[1]:

            sub_ = []
            for k in j[1]:
                    
                    if int('25'+k[0].split('-')[1]) - int(k[3][0][2].split('/')[1]) == -5:
                        # print(k[0])
                        cur.execute("SELECT sub_code_new FROM compare_info WHERE sub_code_old = %s",(k[0]))
                        new = cur.fetchone()
                        if new is not None:
                            k[0] = new[0]

                    sub_.append(k)

            tmp.append({
                'group': j[0],
                'subject': sub_
            })
        use_dict['data'].append({
            'section': i[0],
            'group_subject': tmp
        })
    
    # for i in use_dict['data']:
    #     print(i)
    

    return {
        'data_use': use_dict['data'],
        'sub_code': study_sub_code,
    }
# *************************************************************************************************************************************

# std_id="6221654831"
# data_date="29/03/2023"
# data_time="22:40:43"
# admin_id =1
# get_study_info_for_teacher(std_id, data_date, data_time,admin_id)