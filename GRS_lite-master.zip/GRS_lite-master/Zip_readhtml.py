import pymysql
from pyunpack import Archive
import os

import readhtml
import off_readhtml
import off_readhtml2
import checkpre
import checkCondition
from datetime import date, datetime


UPLOAD_FOLDER = './'
# file = 'test.rar'
# filename = './test_file/test.rar'
# path = './unzipfile'


def connect_db(dbname):
    mydb = pymysql.connect(
        host="10.36.16.177",
        user="root",
        port=3306,
        password="0948544473Za@",
        database="graduation_requirments_system"
    )
    return mydb

def find_edit(edit_):
    n = []
    for i in edit_:
        m = []
        for j in range(int(i), int(i)+5):
            m.append(j)
        n.append(m)
    return (n)


def edit_use(num, n_edit, edit_):
    for i, v in enumerate(n_edit):
        if int(num) in v:
            return (edit_[i])


def upload_zip_html(file_path, file_name, path,year,admin_id,section):
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    today = date.today()
    current_day = today.strftime("%d/%m/%Y")
    target = os.path.join(UPLOAD_FOLDER, 'unzipfile')
    if not os.path.isdir(target):
        os.mkdir(target)
    Archive(file_path).extractall(path)

    dir_list = os.listdir(f"{path}/{file_name.split('.')[0]}")

    response = {}
    for i in dir_list:
        html_name = i
        print(html_name)
        html_path = f"{path}/{file_name.split('.')[0]}/{i}"
        if i.split('.')[-1] == 'html':
            try:
                print(1)
                html_read = readhtml.ReadHtml(html_path)
                study = html_read.ReadHtml()
                
            except:
                try:
                    print(2)
                    html_read = off_readhtml.ReadHtml(html_path)
                    study = html_read.ReadHtml()
                    
                except:
                    try:
                        print(3)
                        html_read = off_readhtml2.ReadHtml(html_path)
                        study = html_read.ReadHtml()
                        
                    except:
                        return{
                            'message': 'error read html format not match'
                        }
          
            mydb = connect_db('graduation_requirments_system')
            c = mydb.cursor()
            try:
                c.execute("SELECT * FROM student_info WHERE std_id = %s AND deleted = 0  and admin_id = %s", (study[1],admin_id))
                old_student = c.fetchone()
                if old_student is not None:
                    c.execute("UPDATE student_info SET deleted = 1 WHERE std_id = %s and admin_id = %s", (study[1],admin_id))
                    mydb.commit()
            except:
                return{
                    'message': 'error old student data'
                }
            std_info = 0
            
            try:
                c.execute("INSERT INTO student_info (std_id, name, surname, course_id, email, teacher_id, html_status, date_html_upload, html_name, time, html_path, deleted,year,admin_id,section) VALUES (%s, %s ,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);",
                                      (study[1], study[2], study[3], "Q03-60", "NNN", "NNN", 1, current_day,html_name, current_time, html_path, 0,year,admin_id,section))
                mydb.commit()
                std_info = 1
                
            except Exception as e:
                std_info = 0
                response = {"message": "error insert student_info"}
            if std_info == 1:
                c.execute(
                    "SELECT * FROM study_info WHERE std_id = %s AND deleted = 0 and admin_id = %s", (study[1],admin_id))
                old_study = c.fetchone()
                if old_study is not None:
                    c.execute(
                        "UPDATE study_info SET deleted = 1 WHERE std_id = %s and admin_id = %s ;", (study[1],admin_id))
                    mydb.commit()
                try:
                    for i, v in enumerate(study[0]):
                        c.execute("SELECT * FROM subject_info WHERE sub_id = %s", (str(v[0])))
                        old_sub = c.fetchone()

                        if old_sub is None:

                            edit_ = ['2559','2564']
                            n_edit = find_edit(edit_)
                            edit = edit_use(int(v[5])+543, n_edit, edit_)
                            ver= str(edit)[2]+str(edit)[3]
  
                            sql = "INSERT INTO subject_info (sub_code, sub_id, section, group_, subject_group, subgroup, subject_name, credit, affiliation, edition, course_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                            val = (str(v[0])+'-'+str(ver), str(v[0]), 'หมวดวิชาเลือกเสรี', 'None', 'None', 'None',str(v[1]),str(v[3]), 'None', str(edit), 'None')
                            c.execute(sql, val)
                            mydb.commit()

                        c.execute("INSERT INTO study_info (std_id, sub_id, grade, semester, year, date,time,deleted,admin_id) VALUES (%s ,%s,%s,%s,%s,%s,%s,%s,%s);",
                                  (study[1], v[0], v[2], v[4], v[5], current_day, current_time, 0,admin_id))
                        mydb.commit()
                except Exception as e:
                    return {
                        'message': 'error insert study_info',
                        'error': str(e)
                    }
                mydb.commit()
                mydb.close()

                try:
                    checkp = checkpre.checkPRE(
                        study[1], current_day, current_time,admin_id)
                    checkp.check_pre()

                except Exception as e:
                    return {
                        'message': 'checkp fail',
                        'error': str(e)
                    }
                try:
                    checkc = checkCondition.checkcond(
                        study[1], current_day, current_time,admin_id)
                    checkc.check_cond()

                except Exception as e:
                    return {
                        'message': 'checkc fail',
                        'error': str(e)
                    }
                response = {"message": "success"}
            else:
                response = {
                    'message': 'error insert student_info'
                }
    return  response 
    # return {
    #     'message': 'success'
    # }


# upload_zip_html(filename,path)
