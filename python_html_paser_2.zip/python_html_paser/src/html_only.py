import os, shutil,string,random
import shutil
folder = './drop_file_to_me'
fold_name = "out"+''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(10))
os.mkdir(f"./out_html/{fold_name}")
os.mkdir(f"./out_html/{fold_name}/{fold_name}")
for filename in os.listdir(folder):
    name = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(10))
    file_path = os.path.join(folder, filename)
    try:
        if os.path.isdir(file_path):
            shutil.rmtree(file_path)
            print('Deleted %s' % file_path)
        elif os.path.isfile(file_path):
            # change file name
            os.rename(file_path, f"./out_html/{fold_name}/{fold_name}/e2{name}.html")
        
    except Exception as e:
        print('Failed to delete %s. Reason: %s' % (file_path, e))

# make new folder

shutil.make_archive(f'{fold_name}', 'zip',f"./out_html/{fold_name}")
for filename in os.listdir(f"./out_html"):
     shutil.rmtree(f"./out_html/{filename}")
print("---->finished<----")
