import os, shutil,string,random
import shutil
folder = './drop_file_to_me'
fold_name = "out"+''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(10))
os.mkdir(f"./out_html/{fold_name}")
os.mkdir(f"./out_html/{fold_name}/{fold_name}")
path_found = []
for filename in os.listdir(folder):
    
    file_path = os.path.join(folder, filename)
    try:
        if os.path.isdir(file_path):
          path_found.append(file_path) 
        elif os.path.isfile(file_path):
            os.unlink(file_path)
        
    except Exception as e:
        print('Failed to delete %s. Reason: %s' % (file_path, e))
for i in path_found:
    for filename in os.listdir(i):
        if filename != 'profile.html':
         os.unlink(os.path.join(i, filename))
        else:
           name = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(10))
           os.rename(os.path.join(i, filename), f"./out_html/{fold_name}/{fold_name}/e2{name}.html")
# make new folder

shutil.make_archive(f'{fold_name}', 'zip',f"./out_html/{fold_name}")
for filename in os.listdir(f"./out_html"):
     shutil.rmtree(f"./out_html/{filename}")
for filename in os.listdir(folder):
     file_path = os.path.join(folder, filename)
     if os.path.isdir(file_path):
         shutil.rmtree(file_path)
     else:
         os.unlink(file_path)
print("---->finished<----")
